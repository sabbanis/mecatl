package mecabroker_test

import (
	"encoding/json"
	"os"
	"os/exec"
	"regexp"
	"slices"
	"strings"
	"testing"

	appsv1 "k8s.io/api/apps/v1"
	corev1 "k8s.io/api/core/v1"
	networkingv1 "k8s.io/api/networking/v1"
	"sigs.k8s.io/yaml"
)

func renderChart(t *testing.T, args ...string) string {
	t.Helper()
	if _, err := exec.LookPath("helm"); err != nil {
		t.Fatalf("helm is required for chart render tests: %v", err)
	}
	cmd := exec.Command("helm", args...)
	cmd.Dir = "."
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("helm template: %v\n%s", err, out)
	}
	return string(out)
}

func networkPolicyFromRender(t *testing.T, rendered string) networkingv1.NetworkPolicy {
	t.Helper()
	for _, document := range strings.Split(rendered, "\n---") {
		var meta struct {
			Kind string `yaml:"kind"`
		}
		if err := yaml.Unmarshal([]byte(document), &meta); err != nil || meta.Kind != "NetworkPolicy" {
			continue
		}
		var policy networkingv1.NetworkPolicy
		if err := yaml.Unmarshal([]byte(document), &policy); err != nil {
			t.Fatal(err)
		}
		return policy
	}
	t.Fatal("rendered chart has no NetworkPolicy")
	return networkingv1.NetworkPolicy{}
}

func configMapFromRender(t *testing.T, rendered string) corev1.ConfigMap {
	t.Helper()
	for _, document := range strings.Split(rendered, "\n---") {
		var configMap corev1.ConfigMap
		if yaml.Unmarshal([]byte(document), &configMap) == nil && configMap.Kind == "ConfigMap" {
			return configMap
		}
	}
	t.Fatal("rendered chart has no ConfigMap")
	return corev1.ConfigMap{}
}

func deploymentFromRender(t *testing.T, rendered string) appsv1.Deployment {
	t.Helper()
	for _, document := range strings.Split(rendered, "\n---") {
		var deployment appsv1.Deployment
		if yaml.Unmarshal([]byte(document), &deployment) == nil && deployment.Kind == "Deployment" {
			return deployment
		}
	}
	t.Fatal("rendered chart has no Deployment")
	return appsv1.Deployment{}
}

func TestManagedMCPDCRRequiresExplicitOAuth2Endpoints(t *testing.T) {
	args := []string{"template", "production", ".", "-f", "ci/managed-mcp-values.yaml",
		"--set", "mcp.servers[0].auth.oauth.client.mode=dcr",
		"--set", "mcp.servers[0].auth.oauth.client.dcr.discoveryURL=https://github.example/register",
		"--set", "mcp.servers[0].auth.oauth.upstream.mode=oidc",
	}
	if output, err := exec.Command("helm", args...).CombinedOutput(); err == nil {
		t.Fatalf("accepted issuer-only DCR render:\n%s", output)
	}
}
func TestSingletonBrokerRemediation_Scenario4_NetworkPolicyValuesRenderExactly(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `networkPolicy.publicFrom=[{"ipBlock":{"cidr":"192.0.2.0/24"}}]`)
	policy := networkPolicyFromRender(t, rendered)
	if len(policy.Spec.Ingress) != 1 || len(policy.Spec.Ingress[0].From) != 1 || policy.Spec.Ingress[0].Ports[0].Port.String() != "public" {
		t.Fatalf("multiplexed public ingress = %#v", policy.Spec.Ingress)
	}
	if _, err := exec.Command("helm", "template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `networkPolicy.mecak8sFrom=[{"ipBlock":{"cidr":"192.0.2.0/24"}}]`).CombinedOutput(); err == nil {
		t.Fatal("ineffective route-specific network policy key was accepted")
	}
}

func TestNetworkPolicyIngressDefaultsToDenyAndUsesPublicContainerPort(t *testing.T) {
	t.Run("empty peers default deny", func(t *testing.T) {
		rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", "networkPolicy.publicFrom=[]")
		policy := networkPolicyFromRender(t, rendered)
		if len(policy.Spec.Ingress) != 0 {
			t.Fatalf("empty peer lists rendered %d ingress rules", len(policy.Spec.Ingress))
		}
	})
	t.Run("configured peers target the multiplexed public port", func(t *testing.T) {
		rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `networkPolicy.publicFrom=[{"ipBlock":{"cidr":"192.0.2.0/24"}}]`)
		policy := networkPolicyFromRender(t, rendered)
		if len(policy.Spec.Ingress) != 1 || policy.Spec.Ingress[0].Ports[0].Port.String() != "public" {
			t.Fatalf("unexpected ingress: %#v", policy.Spec.Ingress)
		}
	})
}

func TestSingletonBrokerRemediation_Scenario4_DigestRequired(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml")
	var images []string
	for _, document := range strings.Split(rendered, "\n---") {
		var deployment appsv1.Deployment
		if yaml.Unmarshal([]byte(document), &deployment) != nil || deployment.Kind != "Deployment" {
			continue
		}
		for _, container := range append(deployment.Spec.Template.Spec.Containers, deployment.Spec.Template.Spec.InitContainers...) {
			images = append(images, container.Image)
		}
	}
	if len(images) == 0 {
		t.Fatal("production render contains no workload images")
	}
	canonical := regexp.MustCompile(`^[^@:[:space:]]+(?:/[^@:[:space:]]+)*@sha256:[0-9a-f]{64}$`)
	for _, image := range images {
		if !canonical.MatchString(image) {
			t.Fatalf("production image is not repository@canonical-digest: %q", image)
		}
	}
	for _, set := range []string{"image.digest=", "image.digest=sha256:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", "image.digest=sha256:deadbeef", "image.tag=v1"} {
		if _, err := exec.Command("helm", "template", "production", ".", "-f", "ci/production-values.yaml", "--set", set).CombinedOutput(); err == nil {
			t.Fatalf("accepted invalid or ambiguous image override %q", set)
		}
	}
}

func TestSingletonBrokerRemediation_Scenario4_SingletonTopologyAndExposure(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml")
	var deployment appsv1.Deployment
	var service corev1.Service
	var deployments, services, highAvailability int
	for _, document := range strings.Split(rendered, "\n---") {
		var meta struct {
			Kind string `yaml:"kind"`
		}
		if yaml.Unmarshal([]byte(document), &meta) != nil {
			continue
		}
		switch meta.Kind {
		case "Deployment":
			if err := yaml.Unmarshal([]byte(document), &deployment); err != nil {
				t.Fatal(err)
			}
			if deployment.Spec.Replicas == nil || *deployment.Spec.Replicas != 1 || deployment.Spec.Strategy.Type != appsv1.RecreateDeploymentStrategyType {
				t.Fatalf("deployment topology = %#v", deployment.Spec)
			}
			deployments++
		case "Service":
			if err := yaml.Unmarshal([]byte(document), &service); err != nil {
				t.Fatal(err)
			}
			for _, port := range service.Spec.Ports {
				if port.Name == "admin" {
					t.Fatal("admin listener is publicly exposed")
				}
			}
			services++
		case "PodDisruptionBudget", "HorizontalPodAutoscaler":
			highAvailability++
		}
	}
	if deployments != 1 || services != 1 || highAvailability != 0 {
		t.Fatalf("topology objects deployment=%d service=%d HA=%d", deployments, services, highAvailability)
	}
	if len(service.Spec.Ports) != 1 || service.Spec.Ports[0].Name != "public" || service.Spec.Ports[0].Port != 8443 || service.Spec.Ports[0].TargetPort.StrVal != "public" {
		t.Fatalf("public Service port = %#v, want 8443 -> named public container port", service.Spec.Ports)
	}
	pod := deployment.Spec.Template.Spec
	if len(pod.Containers) != 1 {
		t.Fatalf("broker containers = %d, want 1", len(pod.Containers))
	}
	container := pod.Containers[0]
	if !slices.Equal(container.Args, []string{"--config=/etc/mecabroker/broker.json"}) || len(container.Ports) < 1 || container.Ports[0].Name != "public" || container.Ports[0].ContainerPort != 8443 {
		t.Fatalf("broker must use only its canonical config argument: args=%q ports=%#v", container.Args, container.Ports)
	}
	for _, arg := range container.Args {
		if strings.HasPrefix(arg, "--admin-addr=") {
			t.Fatalf("administration listener must use the fixed local endpoint, not an argument: %q", container.Args)
		}
	}
	if pod.AutomountServiceAccountToken == nil || *pod.AutomountServiceAccountToken || pod.SecurityContext == nil || pod.SecurityContext.RunAsNonRoot == nil || !*pod.SecurityContext.RunAsNonRoot || pod.SecurityContext.SeccompProfile == nil {
		t.Fatalf("restrictive pod security = token:%v context:%#v", pod.AutomountServiceAccountToken, pod.SecurityContext)
	}
	security := container.SecurityContext
	if security == nil || security.ReadOnlyRootFilesystem == nil || !*security.ReadOnlyRootFilesystem || security.AllowPrivilegeEscalation == nil || *security.AllowPrivilegeEscalation || len(security.Capabilities.Drop) == 0 {
		t.Fatalf("restrictive container security = %#v", security)
	}
	policy := networkPolicyFromRender(t, rendered)
	if len(policy.Spec.PolicyTypes) != 2 || len(policy.Spec.Ingress) != 1 || len(policy.Spec.Ingress[0].From) == 0 || len(policy.Spec.Egress) == 0 {
		t.Fatalf("default-deny policy with explicit public ingress and operator egress = %#v", policy.Spec)
	}
	for _, policyType := range []networkingv1.PolicyType{networkingv1.PolicyTypeIngress, networkingv1.PolicyTypeEgress} {
		if !slices.Contains(policy.Spec.PolicyTypes, policyType) {
			t.Fatalf("network policy omits %s: %v", policyType, policy.Spec.PolicyTypes)
		}
	}
}

func TestSingletonBrokerRemediation_Scenario4_DeploymentGateIsExecutable(t *testing.T) {
	if _, err := exec.LookPath("task"); err != nil {
		t.Fatalf("task is required for deployment gate: %v", err)
	}
	if _, err := exec.LookPath("helm"); err != nil {
		t.Fatalf("helm is required for deployment gate: %v", err)
	}
	if _, err := exec.LookPath("kubeconform"); err != nil {
		t.Fatalf("kubeconform is required for deployment gate: %v", err)
	}
	cmd := exec.Command("task", "deploy:check")
	cmd.Dir = "../../.."
	if output, err := cmd.CombinedOutput(); err != nil {
		t.Fatalf("task deploy:check: %v\n%s", err, output)
	}

	workflowBody, err := os.ReadFile("../../../.github/workflows/ci.yml")
	if err != nil {
		t.Fatal(err)
	}
	var workflow struct {
		Jobs map[string]struct {
			Needs any              `yaml:"needs"`
			Steps []map[string]any `yaml:"steps"`
		} `yaml:"jobs"`
	}
	if err := yaml.Unmarshal(workflowBody, &workflow); err != nil {
		t.Fatalf("parse CI workflow: %v", err)
	}
	deployment, ok := workflow.Jobs["deployment"]
	if !ok {
		t.Fatal("CI has no required deployment job")
	}
	if deployment.Needs == nil {
		t.Fatal("deployment job is not connected to CI prerequisites")
	}
	runs := map[string]bool{}
	for _, step := range deployment.Steps {
		if run, ok := step["run"].(string); ok {
			runs[strings.TrimSpace(run)] = true
		}
	}
	for _, required := range []string{
		"task deploy:check",
		"go test ./deploy/helm/mecak8s -count=1",
		"go test ./deploy/helm/mecabroker -count=1",
	} {
		if !runs[required] {
			t.Fatalf("deployment job omits required semantic invocation %q", required)
		}
	}
}
func TestInvariant_singleton_broker_release_supply_chain_hardening(t *testing.T) {
	body, err := os.ReadFile("../../../.github/workflows/release.yml")
	if err != nil {
		t.Fatal(err)
	}
	var workflow struct {
		Jobs map[string]struct {
			Steps []map[string]any `yaml:"steps"`
		} `yaml:"jobs"`
	}
	if err := yaml.Unmarshal(body, &workflow); err != nil {
		t.Fatalf("parse release workflow: %v", err)
	}
	approvedSetupKo := "ko-build/setup-ko@61b4d1d396f5b2e7d6bb6fefdce3dc38d1a13445"
	koSteps := 0
	loginSteps := 0
	for jobName, job := range workflow.Jobs {
		for _, step := range job.Steps {
			uses, _ := step["uses"].(string)
			if strings.HasPrefix(uses, "ko-build/setup-ko@") {
				koSteps++
				if uses != approvedSetupKo {
					t.Fatalf("job %s selects an unapproved setup-ko action: %q", jobName, uses)
				}
				with, ok := step["with"].(map[string]any)
				if !ok || with["version"] != "v0.18.1" {
					t.Fatalf("job %s has an unpinned ko tool version: %#v", jobName, step)
				}
			}
			run, _ := step["run"].(string)
			if strings.Contains(run, "secrets.GITHUB_TOKEN") {
				t.Fatalf("job %s interpolates registry credentials in shell: %s", jobName, run)
			}
			if strings.Contains(run, "--password-stdin") {
				loginSteps++
				if !strings.Contains(run, `printf '%s' "$GITHUB_TOKEN"`) {
					t.Fatalf("job %s does not quote the step-scoped credential into password-stdin: %s", jobName, run)
				}
				env, ok := step["env"].(map[string]any)
				if !ok || env["GITHUB_TOKEN"] != "${{ secrets.GITHUB_TOKEN }}" {
					t.Fatalf("job %s login lacks the exact step-scoped credential env: %#v", jobName, step)
				}
			}
		}
	}
	if koSteps != 4 || loginSteps != 6 {
		t.Fatalf("release hardening coverage changed: setup-ko=%d registry-logins=%d", koSteps, loginSteps)
	}
}

func TestReleaseWorkflow_BrokerDigestFlowsToEveryPublishedArtifact(t *testing.T) {
	body, err := os.ReadFile("../../../.github/workflows/release.yml")
	if err != nil {
		t.Fatal(err)
	}
	type job struct {
		Needs   any              `yaml:"needs"`
		Outputs map[string]any   `yaml:"outputs"`
		Env     map[string]any   `yaml:"env"`
		Steps   []map[string]any `yaml:"steps"`
	}
	var workflow struct {
		Concurrency map[string]any `yaml:"concurrency"`
		Jobs        map[string]job `yaml:"jobs"`
	}
	if err := yaml.Unmarshal(body, &workflow); err != nil {
		t.Fatalf("parse release workflow: %v", err)
	}
	if workflow.Concurrency["group"] != "release-${{ inputs.tag || github.ref_name }}" {
		t.Fatalf("release concurrency group = %#v", workflow.Concurrency)
	}
	publisher, ok := workflow.Jobs["publish-mecabroker"]
	if !ok {
		t.Fatal("release workflow has no mecabroker publisher")
	}
	if publisher.Outputs["image_ref"] != "${{ steps.build.outputs.digest }}" || publisher.Outputs["image_digest"] != "${{ steps.build.outputs.image_digest }}" {
		t.Fatalf("publisher outputs do not expose build digest: %#v", publisher.Outputs)
	}
	steps := map[string]map[string]any{}
	for _, step := range publisher.Steps {
		if name, _ := step["name"].(string); name != "" {
			steps[name] = step
		}
	}
	for _, name := range []string{"Sign image (keyless)", "Generate SBOM file", "Attest SBOM (keyless)", "Attest build provenance"} {
		step, ok := steps[name]
		if !ok {
			t.Fatalf("publisher is missing %q", name)
		}
		if name == "Attest build provenance" {
			with, _ := step["with"].(map[string]any)
			if with["subject-digest"] != "${{ steps.build.outputs.image_digest }}" {
				t.Fatalf("provenance does not use build digest: %#v", with)
			}
			continue
		}
		if name == "Generate SBOM file" {
			with, _ := step["with"].(map[string]any)
			if with["image"] != "${{ steps.build.outputs.digest }}" {
				t.Fatalf("SBOM does not use build digest: %#v", with)
			}
			continue
		}
		env, _ := step["env"].(map[string]any)
		if env["IMAGE"] != "${{ steps.build.outputs.digest }}" {
			t.Fatalf("%s does not use build digest: %#v", name, env)
		}
	}
	chart, ok := workflow.Jobs["publish-mecabroker-helm-chart"]
	needsPublisher := false
	if needs, ok := chart.Needs.([]any); ok {
		for _, need := range needs {
			needsPublisher = needsPublisher || need == "publish-mecabroker"
		}
	}
	if !ok || !needsPublisher || chart.Env["IMAGE_REF"] != "${{ needs.publish-mecabroker.outputs.image_ref }}" || chart.Env["IMAGE_DIGEST"] != "${{ needs.publish-mecabroker.outputs.image_digest }}" {
		t.Fatalf("chart publisher is not fed by the image publisher: %#v", chart)
	}
	var packaged bool
	for _, step := range chart.Steps {
		if step["name"] == "helm package" {
			run, _ := step["run"].(string)
			packaged = strings.Contains(run, "digest: ${IMAGE_DIGEST}") && strings.Contains(run, "--app-version \"${VERSION}\"")
		}
	}
	if !packaged {
		t.Fatal("chart package step does not inject the published image digest")
	}
}

func TestMecabrokerChart_DeploymentSecurityAndShutdownBudget(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml")
	var deployment appsv1.Deployment
	for _, document := range strings.Split(rendered, "\n---") {
		var meta struct {
			Kind string `yaml:"kind"`
		}
		if yaml.Unmarshal([]byte(document), &meta) == nil && meta.Kind == "Deployment" {
			if err := yaml.Unmarshal([]byte(document), &deployment); err != nil {
				t.Fatal(err)
			}
			break
		}
	}
	if deployment.Name == "" {
		t.Fatal("rendered chart has no Deployment")
	}
	pod := deployment.Spec.Template.Spec
	if pod.AutomountServiceAccountToken == nil || *pod.AutomountServiceAccountToken {
		t.Fatal("broker service account token must be isolated")
	}
	if pod.SecurityContext == nil || pod.SecurityContext.RunAsNonRoot == nil || !*pod.SecurityContext.RunAsNonRoot || pod.SecurityContext.SeccompProfile == nil || pod.SecurityContext.SeccompProfile.Type != "RuntimeDefault" || pod.SecurityContext.SeccompProfile.LocalhostProfile != nil {
		t.Fatalf("pod security context = %#v", pod.SecurityContext)
	}
	container := pod.Containers[0]
	if !slices.Equal(container.Args, []string{"--config=/etc/mecabroker/broker.json"}) || len(container.Ports) < 1 || container.Ports[0].Name != "public" || container.Ports[0].ContainerPort != 8443 {
		t.Fatalf("broker must use only its canonical config argument: args=%q ports=%#v", container.Args, container.Ports)
	}
	for _, arg := range container.Args {
		if strings.HasPrefix(arg, "--admin-addr=") {
			t.Fatalf("admin listener must use the fixed local endpoint, not an argument: %q", container.Args)
		}
	}
	for name, probe := range map[string]*corev1.Probe{
		"startup":   container.StartupProbe,
		"readiness": container.ReadinessProbe,
		"liveness":  container.LivenessProbe,
	} {
		if probe == nil || probe.Exec == nil || !slices.Equal(probe.Exec.Command, []string{"/ko-app/mecabroker", map[string]string{"startup": "ready", "readiness": "ready", "liveness": "health"}[name]}) {
			t.Fatalf("%s probe does not invoke the running local admin endpoint: %#v", name, probe)
		}
	}
	if container.Lifecycle == nil || container.Lifecycle.PreStop == nil || container.Lifecycle.PreStop.Exec == nil || !slices.Equal(container.Lifecycle.PreStop.Exec.Command, []string{"/ko-app/mecabroker", "drain"}) {
		t.Fatalf("preStop does not invoke the running local admin endpoint: %#v", container.Lifecycle)
	}
	if container.SecurityContext == nil || container.SecurityContext.ReadOnlyRootFilesystem == nil || !*container.SecurityContext.ReadOnlyRootFilesystem || container.SecurityContext.AllowPrivilegeEscalation == nil || *container.SecurityContext.AllowPrivilegeEscalation || !slices.Equal(container.SecurityContext.Capabilities.Drop, []corev1.Capability{"ALL"}) || container.SecurityContext.SeccompProfile == nil || container.SecurityContext.SeccompProfile.Type != "RuntimeDefault" || container.SecurityContext.SeccompProfile.LocalhostProfile != nil {
		t.Fatalf("container security context = %#v", container.SecurityContext)
	}
	if got := container.Resources.Requests.Cpu().String(); got != "100m" {
		t.Fatalf("cpu request = %q, want 100m", got)
	}
	if got := container.Resources.Requests.Memory().String(); got != "128Mi" {
		t.Fatalf("memory request = %q, want 128Mi", got)
	}
	if got := container.Resources.Limits.Cpu().String(); got != "1" {
		t.Fatalf("cpu limit = %q, want 1", got)
	}
	if got := container.Resources.Limits.Memory().String(); got != "512Mi" {
		t.Fatalf("memory limit = %q, want 512Mi", got)
	}
	if container.Lifecycle == nil || container.Lifecycle.PreStop == nil || container.Lifecycle.PreStop.Exec == nil {
		t.Fatal("missing drain preStop")
	}
	if pod.TerminationGracePeriodSeconds == nil || *pod.TerminationGracePeriodSeconds <= 62 {
		t.Fatalf("grace = %v, want > 62", pod.TerminationGracePeriodSeconds)
	}
	config := configMapFromRender(t, rendered).Data["broker.json"]
	for _, want := range []string{`"api_version": "mecabroker.mecatl.dev/v1"`, `"max_handles": 128`, `"max_receipts": 4096`, `"max_active_executes": 64`, `"max_logical_sessions": 1024`, `"logical_retention": "86400s"`, `"max_pending_auth_states": 1024`} {
		if !strings.Contains(config, want) {
			t.Fatalf("config document missing runtime bound %q: %s", want, config)
		}
	}
	for _, args := range [][]string{
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set", "terminationGracePeriodSeconds=62"},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set", "transport.dialTimeoutSeconds=5"},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `networkPolicy.operatorEgress=[{}]`},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `networkPolicy.operatorEgress=[{"to":[{"ipBlock":{"cidr":"192.0.2.0/24"}}]}]`},
	} {
		if _, err := exec.Command("helm", args...).CombinedOutput(); err == nil {
			t.Fatalf("accepted invalid values %q", args)
		}
	}
}

func TestMecabrokerChart_ExplicitEgressAndDigestRender(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml")
	policy := networkPolicyFromRender(t, rendered)
	if len(policy.Spec.Egress) != 1 || len(policy.Spec.Egress[0].To) != 1 || len(policy.Spec.Egress[0].Ports) != 1 {
		t.Fatalf("explicit egress = %#v", policy.Spec.Egress)
	}
	if !strings.Contains(rendered, "ghcr.io/stacklok/mecatl/mecabroker@sha256:") {
		t.Fatal("image did not render repository@digest")
	}
}

func TestMecabrokerChart_CanonicalConfigAndSecretCustody(t *testing.T) {
	rendered := renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml")
	configMap := configMapFromRender(t, rendered)
	var config map[string]any
	if err := json.Unmarshal([]byte(configMap.Data["broker.json"]), &config); err != nil {
		t.Fatalf("broker.json is not JSON: %v", err)
	}
	for _, field := range []string{"api_version", "listener", "workload_jwt", "callback_url", "profiles", "drain", "transport", "runtime"} {
		if _, ok := config[field]; !ok {
			t.Fatalf("canonical config omits %q: %#v", field, config)
		}
	}
	if config["api_version"] != "mecabroker.mecatl.dev/v1" {
		t.Fatalf("config API version = %v", config["api_version"])
	}
	profiles := config["profiles"].([]any)
	oauth := profiles[0].(map[string]any)["oauth"].(map[string]any)
	if oauth["client_secret_file"] != "/var/run/mecabroker/oauth/0/client-secret" {
		t.Fatalf("OAuth secret file = %v", oauth["client_secret_file"])
	}
	tools := profiles[0].(map[string]any)["tools"].([]any)
	if tools[0].(map[string]any)["read_only"] != true {
		t.Fatalf("static tool did not render file-config field spelling: %#v", tools[0])
	}
	if strings.Contains(configMap.Data["broker.json"], "mecabroker-upstream") {
		t.Fatalf("config map contains OAuth Secret reference or content: %s", configMap.Data["broker.json"])
	}

	deployment := deploymentFromRender(t, rendered)
	container := deployment.Spec.Template.Spec.Containers[0]
	if !slices.Equal(container.Args, []string{"--config=/etc/mecabroker/broker.json"}) || len(container.Env) != 0 {
		t.Fatalf("broker args/env = %q/%#v", container.Args, container.Env)
	}
	volumes := map[string]corev1.Volume{}
	for _, volume := range deployment.Spec.Template.Spec.Volumes {
		volumes[volume.Name] = volume
	}
	tls := volumes["tls"].Secret
	if tls == nil || tls.SecretName != "mecabroker-tls" || len(tls.Items) != 2 || tls.Items[0].Key != "tls.crt" || tls.Items[0].Path != "tls.crt" || tls.Items[1].Key != "tls.key" || tls.Items[1].Path != "tls.key" {
		t.Fatalf("TLS Secret volume must select its exact certificate and key: %#v", tls)
	}
	var tlsMounted bool
	for _, mount := range container.VolumeMounts {
		if mount.Name == "tls" && mount.MountPath == "/var/run/mecabroker/tls" && mount.ReadOnly {
			tlsMounted = true
		}
	}
	if !tlsMounted {
		t.Fatalf("TLS Secret is not privately mounted read-only: %#v", container.VolumeMounts)
	}
	for _, want := range []struct {
		volume, secretName, key, path, mountPath string
	}{
		{"workload-jwt", "mecabroker-workload-jwt", "ca.pem", "ca.pem", "/var/run/mecabroker/workload-jwt"},
		{"oauth-client-secret-0", "mecabroker-upstream", "client-secret", "client-secret", "/var/run/mecabroker/oauth/0"},
	} {
		secret := volumes[want.volume].Secret
		if secret == nil || secret.SecretName != want.secretName || len(secret.Items) != 1 || secret.Items[0].Key != want.key || secret.Items[0].Path != want.path {
			t.Fatalf("%s Secret volume must select its exact key: %#v", want.volume, secret)
		}
		var mounted bool
		for _, mount := range container.VolumeMounts {
			if mount.Name == want.volume && mount.MountPath == want.mountPath && mount.ReadOnly {
				mounted = true
			}
		}
		if !mounted {
			t.Fatalf("%s Secret is not privately mounted read-only: %#v", want.volume, container.VolumeMounts)
		}
	}
}

func TestMecabrokerChart_SchemaAndRolloutRejectEscapes(t *testing.T) {
	for _, args := range [][]string{
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set", "brokerConfig={}"},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `extraEnv=[]`},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `profiles=[{"name":"issues","url":"https://mcp.example.invalid/mcp","auth":"oauth","oauth":{"issuer":"https://identity.example.invalid","clientID":"id","clientSecret":"inline","scopes":[],"requestRefreshToken":false},"tools":[]}]`},
		{"template", "production", ".", "-f", "ci/production-values.yaml", "--set-json", `profiles=[{"name":"issues","url":"https://mcp.example.invalid/mcp","auth":"oauth","tools":[]}]`},
	} {
		if output, err := exec.Command("helm", args...).CombinedOutput(); err == nil {
			t.Fatalf("accepted schema-bypassing values %q: %s", args, output)
		}
	}
	before := deploymentFromRender(t, renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml"))
	after := deploymentFromRender(t, renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml", "--set", "rollout.restartToken=rotated-20260912"))
	if before.Spec.Template.Annotations["rollout/restart-token"] != "" || after.Spec.Template.Annotations["rollout/restart-token"] != "rotated-20260912" {
		t.Fatalf("restart token annotations = before:%#v after:%#v", before.Spec.Template.Annotations, after.Spec.Template.Annotations)
	}
	changedConfig := deploymentFromRender(t, renderChart(t, "template", "production", ".", "-f", "ci/production-values.yaml", "--set", "callbackURL=https://broker.example.invalid/rotated"))
	if before.Spec.Template.Annotations["checksum/broker-config"] == changedConfig.Spec.Template.Annotations["checksum/broker-config"] {
		t.Fatal("config document change did not update pod template checksum")
	}
}
